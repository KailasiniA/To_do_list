package com.example.todolistappjava;

import android.app.DatePickerDialog;
import android.app.AlertDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

public class MainActivity extends AppCompatActivity implements TaskAdapter.TaskClickListener {
    private RecyclerView recyclerView;
    private TaskAdapter taskAdapter;
    private ArrayList<Task> taskList;
    private EditText editTextTask;
    private Button buttonAddTask;
    private Button buttonSetDeadline;
    private Date deadline;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);
        editTextTask = findViewById(R.id.editTextTask);
        buttonAddTask = findViewById(R.id.buttonAddTask);
        buttonSetDeadline = findViewById(R.id.buttonSetDeadline);

        taskList = new ArrayList<>();
        taskAdapter = new TaskAdapter(taskList, this);
        recyclerView.setAdapter(taskAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        buttonSetDeadline.setOnClickListener(v -> showDatePicker());
        buttonAddTask.setOnClickListener(v -> addTask());
    }

    private void showDatePicker() {
        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(this, (view, selectedYear, selectedMonth, selectedDay) -> {
            Calendar selectedDate = Calendar.getInstance();
            selectedDate.set(selectedYear, selectedMonth, selectedDay);
            deadline = selectedDate.getTime();
            buttonSetDeadline.setText("Deadline: " + selectedDay + "/" + (selectedMonth + 1) + "/" + selectedYear);
        }, year, month, day);
        datePickerDialog.show();
    }

    private void addTask() {
        String taskTitle = editTextTask.getText().toString().trim();
        if (taskTitle.isEmpty()) {
            Toast.makeText(this, "Please enter a task", Toast.LENGTH_SHORT).show();
            return;
        }
        if (deadline == null) {
            Toast.makeText(this, "Please set a deadline", Toast.LENGTH_SHORT).show();
            return;
        }

        Task task = new Task(taskTitle, deadline);
        taskList.add(task);
        taskAdapter.notifyItemInserted(taskList.size() - 1);
        editTextTask.setText("");
        deadline = null; // Reset deadline
        buttonSetDeadline.setText("Set Deadline");
        Toast.makeText(this, "Added: " + taskTitle, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onTaskClick(int position) {
        showTaskOptionsDialog(position);
    }

    private void showTaskOptionsDialog(int position) {
        new AlertDialog.Builder(this)
                .setTitle("Task Options")
                .setMessage("Do you want to edit or delete this task?")
                .setPositiveButton("Edit", (dialog, which) -> editTask(position))
                .setNegativeButton("Delete", (dialog, which) -> deleteTask(position))
                .setNeutralButton("Cancel", null)
                .show();
    }

    private void editTask(int position) {
        Task task = taskList.get(position);
        editTextTask.setText(task.getTitle());
        deadline = task.getDeadline(); // Restore deadline for editing
        buttonSetDeadline.setText("Deadline: " + task.getDeadlineString());
        taskList.remove(position); // Remove the task for editing
        taskAdapter.notifyItemRemoved(position);
        Toast.makeText(this, "Editing task: " + task.getTitle(), Toast.LENGTH_SHORT).show();
    }

    private void deleteTask(int position) {
        Task removedTask = taskList.get(position);
        taskAdapter.removeTask(position);
        Toast.makeText(this, "Deleted: " + removedTask.getTitle(), Toast.LENGTH_SHORT).show();
    }
}
