package com.example.todolistappjava;

import java.util.Date;
import java.text.SimpleDateFormat;

public class Task {
    private String title;
    private Date deadline;
    private boolean isCompleted;

    public Task(String title, Date deadline) {
        this.title = title;
        this.deadline = deadline;
        this.isCompleted = false;
    }

    public String getTitle() {
        return title;
    }

    public Date getDeadline() {
        return deadline;
    }

    public boolean isCompleted() {
        return isCompleted;
    }

    public void setCompleted(boolean completed) {
        isCompleted = completed;
    }

    public String getDeadlineString() {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        return sdf.format(deadline);
    }
}
